from pathlib import Path
BANNED = ["requests", "urllib", "http.client", "subprocess", "os.system", "eval(", "exec(", "selenium", "playwright", "socket", "pynput", "pyautogui", "credential", "password", "medical_device_control", "surgery_control", "laser_control", "injection_schedule"]

def audit(path="src"):
    findings=[]
    for p in Path(path).rglob("*.py"):
        if p.name == "static_audit.py":
            continue
        txt=p.read_text(encoding="utf-8", errors="ignore")
        for b in BANNED:
            if b in txt:
                findings.append({"file":str(p), "term":b})
    return {"pass": len(findings)==0, "finding_count": len(findings), "findings": findings, "policy": "No network imports, subprocess, dynamic execution, credential capture, device control, or clinical decision automation in offline core."}
