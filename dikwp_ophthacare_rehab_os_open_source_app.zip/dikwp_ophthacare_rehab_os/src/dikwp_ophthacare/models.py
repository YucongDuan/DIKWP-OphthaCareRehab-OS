from dataclasses import dataclass, field
from typing import List, Dict, Any

@dataclass
class EyeCareCase:
    case_id: str
    setting: str
    patient_group: str
    care_goal: str
    constraints: List[str]
    diseases: List[Dict[str, Any]]
    ai_inputs: List[Dict[str, Any]]
    rehab_needs: List[Dict[str, Any]]
    safety_events: List[Dict[str, Any]] = field(default_factory=list)

@dataclass
class DecisionCard:
    item_id: str
    topic: str
    risk_score: float
    decision: str
    semantic_stability: str
    rationale: str
    required_reviewer: str

@dataclass
class ActionTicket:
    ticket_id: str
    source_id: str
    owner: str
    priority: str
    action: str
    evidence_refs: List[str]
    rollback_plan: str
    kill_conditions: List[str]
