def main():
    print("DIKWP OphthaCareRehab OS: use `ophthacare analyze examples/sample_ophthalmology_care_case.json --out outputs/demo`.")
if __name__ == "__main__":
    main()
