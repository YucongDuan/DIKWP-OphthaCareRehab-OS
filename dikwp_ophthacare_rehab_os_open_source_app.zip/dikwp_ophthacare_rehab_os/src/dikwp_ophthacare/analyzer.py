import json, csv, re
from pathlib import Path
from .models import EyeCareCase, DecisionCard, ActionTicket

URGENT_TERMS = [
    "sudden vision loss", "curtain", "flashes", "floaters", "eye trauma", "chemical burn",
    "painful red eye", "corneal ulcer", "endophthalmitis", "acute angle closure",
    "giant cell arteritis", "jaw claudication", "diplopia with neurologic signs"
]
HIGH_RISK_DISEASES = ["retinal detachment", "acute glaucoma", "endophthalmitis", "infectious keratitis", "ocular trauma", "giant cell arteritis"]
REVIEW_DISEASES = ["diabetic retinopathy", "diabetic macular edema", "glaucoma", "age-related macular degeneration", "uveitis", "myopia control", "amblyopia", "cataract", "dry eye"]


def _norm(s):
    return str(s or "").lower()


def load_case(path: str) -> EyeCareCase:
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    return EyeCareCase(**data)


def risk_from_disease(d):
    name = _norm(d.get("name"))
    severity = _norm(d.get("severity"))
    missing = d.get("missing_evidence", []) or []
    score = 0.18
    if any(x in name for x in HIGH_RISK_DISEASES):
        score += 0.55
    if any(x in name for x in REVIEW_DISEASES):
        score += 0.25
    if severity in ["severe", "sight-threatening", "urgent"]:
        score += 0.25
    if missing:
        score += min(0.2, 0.05 * len(missing))
    return min(score, 1.0)


def decision_for_risk(score, high_impact=False):
    if score >= 0.75 or high_impact:
        return "urgent_or_specialist_review_required"
    if score >= 0.45:
        return "ophthalmologist_review_required"
    if score >= 0.25:
        return "clinician_review_before_patient_use"
    return "education_or_rehab_draft_allowed"


def semantic_stability(score, missing_count):
    if score >= 0.75:
        return "S1 Fragile Closure"
    if missing_count >= 3:
        return "S2 Provisional Closure"
    if score >= 0.45:
        return "S3 Supported Closure"
    return "S4 Stable Operational Closure"


def analyze_case(case: EyeCareCase):
    decision_cards = []
    tickets = []
    ledger = []
    ai_queue = []
    disease_rows = []
    red_flags = []

    for idx, d in enumerate(case.diseases, 1):
        rid = d.get("id", f"d{idx}")
        risk = risk_from_disease(d)
        missing = d.get("missing_evidence", []) or []
        high_impact = risk >= 0.75
        decision = decision_for_risk(risk, high_impact)
        stability = semantic_stability(risk, len(missing))
        reviewer = "ophthalmologist" if risk < 0.75 else "retina/glaucoma/cornea/neuro-ophthalmology specialist or emergency service"
        rationale = f"Disease={d.get('name')}; severity={d.get('severity')}; missing={len(missing)}; AI role must remain review-only."
        decision_cards.append(DecisionCard(rid, d.get("name","unknown"), round(risk,3), decision, stability, rationale, reviewer))
        priority = "high" if risk >= 0.75 else "medium" if risk >= 0.45 else "low"
        tickets.append(ActionTicket(
            ticket_id=f"T-{rid}", source_id=rid, owner=reviewer, priority=priority,
            action=f"Review {d.get('name')} pathway, missing evidence, follow-up timing, and rehab support before patient-facing use.",
            evidence_refs=d.get("evidence_refs", []),
            rollback_plan="Remove draft from patient-facing workflow; revert to clinician-authored plan.",
            kill_conditions=["patient-specific directive without clinician sign-off", "missing visual acuity/IOP/imaging where required", "urgent red flag present"]
        ))
        ledger.append({
            "id": rid,
            "D": {"disease": d.get("name"), "severity": d.get("severity"), "evidence_refs": d.get("evidence_refs", [])},
            "I": {"modality": d.get("modality"), "missing_evidence": missing, "symptom_timecourse": d.get("timecourse")},
            "K": {"clinical_area": d.get("clinical_area"), "pathway": d.get("pathway_hint")},
            "W": {"patient_safety": "clinician review required for diagnosis/treatment", "equity": d.get("access_barrier", "not specified")},
            "P": {"goal": case.care_goal, "constraints": case.constraints, "feedback": "follow-up outcome and clinician correction"},
            "R": {"risk_score": round(risk,3), "semantic_stability": stability, "residual": missing}
        })
        disease_rows.append([rid, d.get("name"), d.get("clinical_area"), d.get("severity"), round(risk,3), decision, stability])

    for idx, ai in enumerate(case.ai_inputs, 1):
        rid = ai.get("id", f"ai{idx}")
        use = _norm(ai.get("intended_use"))
        risk = 0.2
        if "diagnosis" in use or "treatment" in use or "injection" in use or "surgery" in use:
            risk += 0.5
        if ai.get("patient_specific", False):
            risk += 0.2
        if ai.get("unvalidated", True):
            risk += 0.15
        decision = decision_for_risk(min(risk,1.0), risk>=0.75)
        ai_queue.append([rid, ai.get("model_name"), ai.get("intended_use"), round(min(risk,1.0),3), decision, ai.get("validation_status","unknown")])

    text = json.dumps(case.__dict__, ensure_ascii=False).lower()
    for term in URGENT_TERMS:
        if term in text:
            red_flags.append(term)

    rehab_plan = build_rehab_plan(case)
    patient_pack = build_patient_education(case, red_flags)
    clinician_board = build_clinician_board(case, decision_cards, red_flags)
    followup_plan = build_followup_plan(case, decision_cards)
    return {
        "case": case,
        "decision_cards": decision_cards,
        "tickets": tickets,
        "ledger": ledger,
        "disease_rows": disease_rows,
        "ai_queue": ai_queue,
        "red_flags": red_flags,
        "rehab_plan": rehab_plan,
        "patient_pack": patient_pack,
        "clinician_board": clinician_board,
        "followup_plan": followup_plan
    }


def build_rehab_plan(case):
    lines = ["# Rehabilitation and Low-Vision Support Plan", "", "This is a clinician-review draft, not a prescription.", ""]
    if not case.rehab_needs:
        lines.append("No rehabilitation needs were supplied. Add visual acuity, contrast sensitivity, field loss, reading goals, mobility goals, and daily living barriers.")
    for r in case.rehab_needs:
        lines.append(f"## {r.get('id','rehab')}: {r.get('need','rehabilitation need')}")
        lines.append(f"- Functional goal: {r.get('functional_goal','not specified')}")
        lines.append(f"- Support options for review: {', '.join(r.get('support_options', [])) or 'not specified'}")
        lines.append(f"- Residual: {', '.join(r.get('missing_evidence', [])) or 'none listed'}")
        lines.append("- Required review: ophthalmologist / optometrist / low-vision rehabilitation specialist as appropriate.")
        lines.append("")
    return "\n".join(lines)


def build_patient_education(case, red_flags):
    lines = ["# Patient Education Draft Pack", "", "Use after clinician review. Avoid replacing clinical judgment.", ""]
    if red_flags:
        lines += ["## Safety Warning", "The case contains urgent red-flag language. Do not use generic education alone; route to urgent clinical review.", ""]
    for d in case.diseases:
        lines.append(f"## {d.get('name')}")
        lines.append("- What this draft can do: explain the condition in plain language after clinician review.")
        lines.append("- What this draft cannot do: diagnose, prescribe, change treatment, or decide follow-up urgency.")
        lines.append(f"- Questions to ask the doctor: What evidence supports the diagnosis? What warning signs require urgent care? What follow-up interval applies to me?")
        lines.append("")
    return "\n".join(lines)


def build_clinician_board(case, cards, red_flags):
    lines = ["# Ophthalmology Review Board Brief", "", f"Case: {case.case_id}", f"Setting: {case.setting}", ""]
    if red_flags:
        lines += ["## Red Flags", *[f"- {x}" for x in red_flags], ""]
    lines.append("## Decision Cards")
    for c in cards:
        lines.append(f"- {c.item_id}: {c.topic} | {c.decision} | risk={c.risk_score} | {c.semantic_stability}")
    lines.append("")
    lines.append("## Board Questions")
    lines.append("1. Is the diagnosis already clinician-confirmed, suspected, or just a patient concern?")
    lines.append("2. Which imaging or examination evidence is missing?")
    lines.append("3. What is the nearest safe follow-up window?")
    lines.append("4. Which rehabilitation needs should be referred today?")
    lines.append("5. Which AI-generated content must be withheld from patients until reviewed?")
    return "\n".join(lines)


def build_followup_plan(case, cards):
    lines = ["# Follow-up Safety Plan", "", "Clinician review required before patient use.", ""]
    for c in cards:
        if c.risk_score >= 0.75:
            lines.append(f"- {c.topic}: urgent/specialist review. Do not defer based on AI output.")
        elif c.risk_score >= 0.45:
            lines.append(f"- {c.topic}: ophthalmologist review required before treatment or follow-up changes.")
        else:
            lines.append(f"- {c.topic}: education/rehab draft may be prepared, but must be reviewed.")
    return "\n".join(lines)


def write_outputs(result, outdir):
    out = Path(outdir); out.mkdir(parents=True, exist_ok=True)
    case = result["case"]
    report = {
        "system": "DIKWP OphthaCareRehab OS",
        "version": "0.1.0",
        "case_id": case.case_id,
        "setting": case.setting,
        "disease_count": len(case.diseases),
        "ai_input_count": len(case.ai_inputs),
        "rehab_need_count": len(case.rehab_needs),
        "red_flags": result["red_flags"],
        "decision_summary": summary([c.decision for c in result["decision_cards"]]),
        "safety_boundary": "No diagnosis/treatment/prescribing/device control; clinician review required.",
    }
    (out/"ophthacare_report.json").write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    (out/"dikwp_eye_care_ledger.json").write_text(json.dumps(result["ledger"], indent=2, ensure_ascii=False), encoding="utf-8")
    write_csv(out/"disease_pathway_matrix.csv", ["id","disease","clinical_area","severity","risk_score","decision","semantic_stability"], result["disease_rows"])
    write_csv(out/"ai_screening_review_queue.csv", ["id","model_name","intended_use","risk_score","decision","validation_status"], result["ai_queue"])
    write_csv(out/"treatment_review_tickets.csv", ["ticket_id","source_id","owner","priority","action","evidence_refs","rollback_plan","kill_conditions"], [
        [t.ticket_id, t.source_id, t.owner, t.priority, t.action, ";".join(t.evidence_refs), t.rollback_plan, ";".join(t.kill_conditions)] for t in result["tickets"]])
    (out/"rehabilitation_plan.md").write_text(result["rehab_plan"], encoding="utf-8")
    (out/"low_vision_support_plan.md").write_text(result["rehab_plan"], encoding="utf-8")
    (out/"patient_education_pack.md").write_text(result["patient_pack"], encoding="utf-8")
    (out/"clinician_review_board.md").write_text(result["clinician_board"], encoding="utf-8")
    (out/"followup_safety_plan.md").write_text(result["followup_plan"], encoding="utf-8")
    (out/"recommendations.md").write_text(build_recommendations(report), encoding="utf-8")
    return report


def summary(items):
    d = {}
    for x in items:
        d[x] = d.get(x,0)+1
    return d


def write_csv(path, header, rows):
    with path.open("w", newline="", encoding="utf-8") as f:
        w=csv.writer(f); w.writerow(header); w.writerows(rows)


def build_recommendations(report):
    lines = ["# Recommendations", ""]
    lines.append("1. Start with offline, synthetic or de-identified cases.")
    lines.append("2. Use AI only for evidence organization, education drafts, and rehabilitation planning drafts.")
    lines.append("3. Require ophthalmologist review before any patient-specific treatment, follow-up, procedure, injection, laser, surgery, or medication change.")
    lines.append("4. Create local validation records for every AI model before use.")
    lines.append("5. Track red flags, missing evidence, clinician overrides, patient outcomes, and model drift.")
    lines.append("")
    lines.append(f"Decision summary: {report['decision_summary']}")
    return "\n".join(lines)
