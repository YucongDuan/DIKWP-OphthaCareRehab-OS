import argparse, json
from pathlib import Path
from .analyzer import load_case, analyze_case, write_outputs
from .static_audit import audit

ALLOW = "allow_education_or_rehab_draft"
REVIEW = "clinician_review_required"
BLOCK = "block_or_emergency_redirect"
BLOCK_TERMS = ["diagnose and prescribe", "prescribe", "schedule injection", "perform surgery", "laser treatment now", "ignore doctor", "replace ophthalmologist", "emergency treatment plan"]
REVIEW_TERMS = ["patient-specific", "treatment", "diagnosis", "follow-up interval", "anti-vegf", "glaucoma medication", "steroid", "surgery", "implant"]

def guard_text(text):
    low=text.lower()
    if any(t in low for t in BLOCK_TERMS):
        return {"decision": BLOCK, "reason": "Request seeks diagnosis/treatment/prescribing/procedure or replacement of clinician."}
    if any(t in low for t in REVIEW_TERMS):
        return {"decision": REVIEW, "reason": "Clinical or patient-specific topic requires clinician review."}
    return {"decision": ALLOW, "reason": "Conceptual education or rehabilitation draft allowed."}


def main():
    ap=argparse.ArgumentParser()
    sub=ap.add_subparsers(dest="cmd")
    a=sub.add_parser("analyze"); a.add_argument("case"); a.add_argument("--out", default="outputs/demo")
    g=sub.add_parser("guard"); g.add_argument("text")
    s=sub.add_parser("static-audit"); s.add_argument("path", nargs="?", default="src"); s.add_argument("--out")
    args=ap.parse_args()
    if args.cmd=="analyze":
        case=load_case(args.case); res=analyze_case(case); summary=write_outputs(res,args.out)
        print(json.dumps(summary, ensure_ascii=False, indent=2))
    elif args.cmd=="guard":
        print(json.dumps(guard_text(args.text), ensure_ascii=False, indent=2))
    elif args.cmd=="static-audit":
        res=audit(args.path); print(json.dumps(res, indent=2, ensure_ascii=False))
        if args.out:
            Path(args.out).parent.mkdir(parents=True, exist_ok=True)
            Path(args.out).write_text(json.dumps(res, indent=2, ensure_ascii=False), encoding="utf-8")
    else:
        ap.print_help()

if __name__ == "__main__":
    main()
