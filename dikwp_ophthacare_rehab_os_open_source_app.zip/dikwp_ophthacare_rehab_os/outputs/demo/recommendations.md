# Recommendations

1. Start with offline, synthetic or de-identified cases.
2. Use AI only for evidence organization, education drafts, and rehabilitation planning drafts.
3. Require ophthalmologist review before any patient-specific treatment, follow-up, procedure, injection, laser, surgery, or medication change.
4. Create local validation records for every AI model before use.
5. Track red flags, missing evidence, clinician overrides, patient outcomes, and model drift.

Decision summary: {'urgent_or_specialist_review_required': 2, 'ophthalmologist_review_required': 3}