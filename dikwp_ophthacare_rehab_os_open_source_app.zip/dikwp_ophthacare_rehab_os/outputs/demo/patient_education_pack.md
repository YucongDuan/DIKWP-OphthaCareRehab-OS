# Patient Education Draft Pack

Use after clinician review. Avoid replacing clinical judgment.

## Safety Warning
The case contains urgent red-flag language. Do not use generic education alone; route to urgent clinical review.

## diabetic retinopathy with suspected diabetic macular edema
- What this draft can do: explain the condition in plain language after clinician review.
- What this draft cannot do: diagnose, prescribe, change treatment, or decide follow-up urgency.
- Questions to ask the doctor: What evidence supports the diagnosis? What warning signs require urgent care? What follow-up interval applies to me?

## primary open-angle glaucoma follow-up concern
- What this draft can do: explain the condition in plain language after clinician review.
- What this draft cannot do: diagnose, prescribe, change treatment, or decide follow-up urgency.
- Questions to ask the doctor: What evidence supports the diagnosis? What warning signs require urgent care? What follow-up interval applies to me?

## age-related macular degeneration rehabilitation support
- What this draft can do: explain the condition in plain language after clinician review.
- What this draft cannot do: diagnose, prescribe, change treatment, or decide follow-up urgency.
- Questions to ask the doctor: What evidence supports the diagnosis? What warning signs require urgent care? What follow-up interval applies to me?

## pediatric amblyopia adherence support
- What this draft can do: explain the condition in plain language after clinician review.
- What this draft cannot do: diagnose, prescribe, change treatment, or decide follow-up urgency.
- Questions to ask the doctor: What evidence supports the diagnosis? What warning signs require urgent care? What follow-up interval applies to me?

## possible retinal detachment symptoms
- What this draft can do: explain the condition in plain language after clinician review.
- What this draft cannot do: diagnose, prescribe, change treatment, or decide follow-up urgency.
- Questions to ask the doctor: What evidence supports the diagnosis? What warning signs require urgent care? What follow-up interval applies to me?
