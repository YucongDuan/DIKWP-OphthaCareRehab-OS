# Follow-up Safety Plan

Clinician review required before patient use.

- diabetic retinopathy with suspected diabetic macular edema: urgent/specialist review. Do not defer based on AI output.
- primary open-angle glaucoma follow-up concern: ophthalmologist review required before treatment or follow-up changes.
- age-related macular degeneration rehabilitation support: ophthalmologist review required before treatment or follow-up changes.
- pediatric amblyopia adherence support: ophthalmologist review required before treatment or follow-up changes.
- possible retinal detachment symptoms: urgent/specialist review. Do not defer based on AI output.