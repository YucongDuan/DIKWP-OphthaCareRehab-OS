# Rehabilitation and Low-Vision Support Plan

This is a clinician-review draft, not a prescription.

## REHAB-AMD-READING: central vision loss reading support
- Functional goal: read medication labels and phone messages safely
- Support options for review: low-vision optometry referral, magnification training, contrast and lighting adaptation, screen reader orientation
- Residual: reading speed, preferred retinal locus, contrast sensitivity
- Required review: ophthalmologist / optometrist / low-vision rehabilitation specialist as appropriate.

## REHAB-GLAUC-MOBILITY: peripheral field loss mobility safety
- Functional goal: reduce falls and improve navigation in crowded spaces
- Support options for review: orientation and mobility referral, home lighting review, fall risk checklist
- Residual: binocular visual field, fall history
- Required review: ophthalmologist / optometrist / low-vision rehabilitation specialist as appropriate.
