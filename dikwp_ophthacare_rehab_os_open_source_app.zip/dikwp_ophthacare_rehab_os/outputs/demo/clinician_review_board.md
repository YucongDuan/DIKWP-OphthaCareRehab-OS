# Ophthalmology Review Board Brief

Case: ophthacare-demo-001
Setting: tertiary eye hospital model department demo

## Red Flags
- curtain
- flashes
- floaters

## Decision Cards
- DR-DME-001: diabetic retinopathy with suspected diabetic macular edema | urgent_or_specialist_review_required | risk=0.88 | S1 Fragile Closure
- GLAUC-001: primary open-angle glaucoma follow-up concern | ophthalmologist_review_required | risk=0.58 | S2 Provisional Closure
- AMD-001: age-related macular degeneration rehabilitation support | ophthalmologist_review_required | risk=0.58 | S2 Provisional Closure
- PED-AMB-001: pediatric amblyopia adherence support | ophthalmologist_review_required | risk=0.53 | S3 Supported Closure
- URG-RET-001: possible retinal detachment symptoms | urgent_or_specialist_review_required | risk=1.0 | S1 Fragile Closure

## Board Questions
1. Is the diagnosis already clinician-confirmed, suspected, or just a patient concern?
2. Which imaging or examination evidence is missing?
3. What is the nearest safe follow-up window?
4. Which rehabilitation needs should be referred today?
5. Which AI-generated content must be withheld from patients until reviewed?