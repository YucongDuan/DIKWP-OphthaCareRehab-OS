# Clinical Governance Boundary

This system is for education, evidence organization, clinical preparation, rehabilitation drafting, and quality review.

It must not be used for autonomous diagnosis, treatment recommendation, medication prescription, injection scheduling, laser planning, surgery approval, medical device actuation, emergency triage replacement, or clinician replacement.

Every patient-specific treatment or follow-up change must be reviewed by a licensed eye-care professional.
