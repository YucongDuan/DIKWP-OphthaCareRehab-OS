# Roadmap

- v0.2: Add FHIR-compatible data mapping templates.
- v0.3: Add OCT/fundus report intake connectors.
- v0.4: Add local validation dashboard.
- v0.5: Add low-vision rehab outcome tracking.
- v1.0: Release model hospital governance toolkit.
