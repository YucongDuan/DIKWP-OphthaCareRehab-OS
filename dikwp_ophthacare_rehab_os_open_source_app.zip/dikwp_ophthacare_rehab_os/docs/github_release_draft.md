# GitHub Release Draft

DIKWP OphthaCareRehab OS v0.1.0 provides an offline-first ophthalmology care and rehabilitation governance prototype. It turns eye disease cases, imaging AI signals, and rehabilitation needs into DIKWP ledgers, clinician review tickets, patient education drafts, and visual rehabilitation plans.

This release is for education, research, and clinical workflow preparation only. It is not a medical device and does not provide diagnosis or treatment.
