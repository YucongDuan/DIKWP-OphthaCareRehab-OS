# Rehabilitation and Low-Vision Platform

The rehabilitation module supports:

- Reading and magnification needs.
- Contrast, lighting, and home adaptation.
- Peripheral field loss mobility safety.
- Screen reader and digital accessibility orientation.
- Pediatric adherence and school support.
- Fall risk and daily living function review.

It generates drafts for review by ophthalmology, optometry, low-vision rehabilitation, occupational therapy, and orientation/mobility specialists.
