# Patient Education Templates

Templates are written for clinician review. They must not diagnose or prescribe.

Topics include diabetic eye disease, glaucoma follow-up, age-related macular degeneration, cataract surgery preparation, dry eye self-care education, pediatric amblyopia adherence support, low-vision rehabilitation, and urgent red flag explanations.
