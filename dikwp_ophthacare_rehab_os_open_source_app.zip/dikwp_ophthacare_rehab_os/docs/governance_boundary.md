# Governance Boundary

Every output is draft-only unless reviewed by a qualified clinician. The system should be configured to log clinician corrections and residuals. It must never be used to deny care, delay urgent care, or replace clinical evaluation.
