# AI Model Registry and Validation

Each ophthalmic AI model should be registered with:

- Model name and version.
- Intended use.
- Input modality.
- Validation population.
- Performance metrics.
- Known limitations.
- Bias and equity review.
- Maximum control level.
- Prohibited uses.
- Local validation status.

No model should be used for patient-facing decisions without local governance and clinician review.
