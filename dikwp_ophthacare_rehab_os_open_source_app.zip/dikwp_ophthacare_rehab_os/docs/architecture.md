# Architecture

The system follows DIKWP-Mesh 4.0 SemanticClosure.

Input case data is transformed into:

1. DIKWP Eye Care Ledger.
2. Disease Pathway Matrix.
3. AI Screening Review Queue.
4. Treatment Review Action Tickets.
5. Rehabilitation and Low Vision Support Plan.
6. Patient Education Draft Pack.
7. Clinician Review Board Brief.
8. Follow-up Safety Plan.

The offline core never calls external systems and never controls medical devices.
