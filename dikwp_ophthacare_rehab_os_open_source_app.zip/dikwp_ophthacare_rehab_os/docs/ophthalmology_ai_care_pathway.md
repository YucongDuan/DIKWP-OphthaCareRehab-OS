# Ophthalmology AI Care Pathway

The recommended pathway is:

1. De-identified or synthetic case intake.
2. Modality and evidence mapping.
3. Red flag scan.
4. Disease pathway classification.
5. AI input registration and validation status review.
6. Clinician review ticket generation.
7. Patient education draft with safety boundary.
8. Visual rehabilitation and low-vision support draft.
9. Outcome feedback and model drift monitoring.

High-impact clinical changes require ophthalmologist sign-off.
