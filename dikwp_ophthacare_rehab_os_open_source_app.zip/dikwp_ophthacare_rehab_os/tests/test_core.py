from dikwp_ophthacare.analyzer import load_case, analyze_case
from dikwp_ophthacare.cli import guard_text
from dikwp_ophthacare.static_audit import audit

def test_demo_analyze():
    case=load_case('examples/sample_ophthalmology_care_case.json')
    res=analyze_case(case)
    assert len(res['decision_cards']) == 5
    assert any(c.decision == 'urgent_or_specialist_review_required' for c in res['decision_cards'])

def test_guard_blocks_prescribing():
    assert guard_text('diagnose and prescribe glaucoma medication')['decision'] == 'block_or_emergency_redirect'
    assert guard_text('generate patient education draft for low vision rehabilitation')['decision'] == 'allow_education_or_rehab_draft'

def test_static_audit():
    assert audit('src')['pass'] is True
